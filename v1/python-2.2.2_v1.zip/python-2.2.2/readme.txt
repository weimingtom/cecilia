Ctrl + Z : exit
