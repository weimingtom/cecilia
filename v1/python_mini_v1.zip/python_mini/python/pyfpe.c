//20180118
#include "pyconfig.h"
#include "pyfpe.h"

double PyFPE_dummy(void *dummy)
{
	return 1.0;
}
