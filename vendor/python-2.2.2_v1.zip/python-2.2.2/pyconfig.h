#if defined(ANDROID)
#include "pyconfig_android.h"
#elif defined(_MSC_VER)
#include "pyconfig_vc6.h"
#endif
