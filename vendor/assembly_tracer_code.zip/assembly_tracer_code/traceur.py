import dis
import collections
from new_code import *
import copy


ADD_STACK = 3

def op_target(l, f, exc=None):
    if op_target.callback is not None:
        op_target.callback(l, f, exc)
op_target.callback = None


def str_instr(instr):
    offset = str(instr.offset).rjust(8)
    opname = str(instr.opname).ljust(20)
    arg = str(instr.arg).ljust(10) 
    return "{0}  {1} {2} ({3})".format(offset, opname, arg, instr.argval)


class FrameAnalyser:
    def __init__(self, frame):
        self.frame = frame
        self.code = frame.f_code
        self.bytecode = dis.Bytecode(self.code)
        self.cur_i = self.frame.f_lasti

    def current_instr(self):
        return [i for i in self.bytecode if i.offset == self.cur_i][0]

    def next_instr(self):
        return [i for i in self.bytecode if i.offset > self.cur_i][0]

    
class Trace:
    def __init__(self, func):
        self.func = qfunc 

    def call(self, *args, **kwargs):
        self.add_func_to_trace(self.func)
        op_target.callback = self.callback
        try:
            res = self.func(*args, **kwargs)
        except Exception as e:
            res = e
        op_target.callback = None
        return res

    def add_func_to_trace(self, f):
        if not hasattr(f ,"op_debug") and hasattr(f, "__code__"):
            f.__code__ = transform_code(f.__code__, transform=add_debug_op_everywhere, add_stacksize=ADD_STACK)
            f.__globals__['op_target'] = op_target
            f.op_debug = True

    def do_auto_follow(self, stack, frame):
        next_instr = FrameAnalyser(frame).next_instr()
        if "CALL" in next_instr.opname:
            arg = next_instr.arg 
            f_index = (arg & 0xff) + (2 * (arg >> 8))
            called_func = stack[f_index]
            if not hasattr(called_func, "op_debug"):
                self.add_func_to_trace(called_func)            
        

    def do_report(self):
        pass

class DummyTrace(Trace):
    def __init__(self, func):
        self.func = func 
        self.data = collections.OrderedDict()
        self.last_frame = None
        self.known_frame = []
        self.report = []

    def callback(self, stack, frame, exc):
        if frame not in self.known_frame:
            self.known_frame.append(frame)
            self.report.append(" === Entering New Frame {0} ({1}) ===".format(frame.f_code.co_name, id(frame)))
            self.last_frame = frame
        if frame != self.last_frame:
            self.report.append(" === Returning to Frame {0} {1}===".format(frame.f_code.co_name, id(frame)))
            self.last_frame = frame

        self.report.append(str(stack))
        instr = FrameAnalyser(frame).next_instr()
        offset = str(instr.offset).rjust(8)
        opname = str(instr.opname).ljust(20)
        arg = str(instr.arg).ljust(10) 
        self.report.append("{0}  {1} {2} {3}".format(offset, opname, arg, instr.argval))
        self.do_auto_follow(stack, frame)

    def do_report(self):
        print("\n".join(self.report))

class StackTrace(Trace):
    def __init__(self, func):
        self.func = func 
        self.data = collections.OrderedDict()

    def callback(self, stack, frame, exc):
        if frame not in self.data:
            self.data[frame] = {}
        try:
            self.data[frame].setdefault(frame.f_lasti, []).append((copy.deepcopy(stack), exc))
        except:
            self.data[frame].setdefault(frame.f_lasti, []).append((stack, exc))
        self.do_auto_follow(stack, frame)

    def do_report(self):
        for frame in self.data:
            print("===== {0} ====".format(frame.f_code.co_name))
            frame_data = self.data[frame]
            for instr in dis.Bytecode(frame.f_code):
                if instr.opcode != 0:
                     offset = str(instr.offset).rjust(8)
                     opname = str(instr.opname).ljust(20)
                     arg = str(instr.arg).ljust(10) 
                     print ("{0}  {1} {2} {3}".format(offset, opname, arg, instr.argval))
                else:
                     if instr.offset not in frame_data:
                         stacks = ["NOT REACHED"]
                     else:
                         stacks = [stack if stack else "Empty" for stack in frame_data[instr.offset]]
                     
                     if all(stack == stacks[0] for stack in stacks) and len(stacks) > 1:
                         stacks = "Everytime ({0}): ".format(len(stacks)) + str(stacks[0])
                         print(" " * 8 + str(stacks))
                     else:
                         for i, s in enumerate(stacks):
                             print(" " * 8 + str(i) + ": "  + str(s))
                

class StackDebug(Trace):
    def __init__(self, func, auto_follow=True):
        self.func = func 
        self.current_frame = None
        self.auto_follow = auto_follow

    def callback(self, stack, frame, exc):
        if frame is not self.current_frame:
            print("=== Now into {0} ===".format(frame.f_code.co_name))
            self.current_frame = frame
        if self.auto_follow:
            self.do_auto_follow(stack, frame)
        self.break_to_user(stack, frame, exc)
                
    def break_to_user(self, stack, frame, exc):
        self.do_stack(stack, frame, exc, [])
        self.do_list(stack, frame, exc, [])
        self.do_exc(stack, frame, exc, [])
        while True:
            cmd = input("PABG >>").split()
            if not cmd or cmd[0] == "c":
                return None
            try:
                f = getattr(self, "do_" + cmd[0])
            except AttributeError:
                print("??")
                continue
            f(stack, frame, exc, cmd[1:])

    def do_break(self, stack, frame, exc, args):
        pass

    def do_dis(self, stack, frame, exc, args):
        print(dis.Bytecode(frame.f_code, current_offset=frame.f_lasti).dis())

    def do_list(self, stack, frame, exc, args):
        nexti = frame.f_lasti + 1
        for instr in dis.Bytecode(frame.f_code):
            if instr.offset == nexti:
                print (str_instr(instr))
                break

    def do_stack(self, stack, frame, exc, args):
        print (stack)

    def do_exc(self, stack, frame, exc, args):
        print (exc)

    def do_eval(self, stack, frame, exc, args):
        try:
            print (eval(' '.join(args)))
        except BaseException as e:
            print("Error with command p: <{0}>".format(e))

    do_p = do_eval

    def do_raise(self, *args):
        raise ValueError('suce')

    def do_dbg(self, stack, frame, exc, args):
        import pdb; pdb.set_trace()

    def do_help(self, *args):
        print("stack | p | dbg | dis | list")
