import traceur

import dis

class context:
    def __enter__(self):
        return "SOMETHING YOU WILL NOT FORGET"

    def __exit__(*args):
        print("exit called")
        return True


def use_context_manager():
    with context() as c:
        return 2 + 2

def f2(x, *args, **kwargs):
    try:
        return 10 / x
    except:
        return 0

def f1(x):
    y = f2(x, truc=3,lol=4)
    y = f2(0)
    return y + 2



def test(x):
    try:
        try:
            raise ValueError('x')
        except ValueError as e:
            y = 2 + 2 + test.lol
    except:
        x = 4


def make_cls(v):
    class X:
        def __call_(self):
            return v + __class__

    return X

class A:
    def __call_(self):
        return self

    def truc(self, v):
        return v


def test_id():
    a = A()
    print(id(a.truc) == id(a.truc))
    print(a.truc is a.truc)
    
def list_comprehension(v):
    return [x * v for x in range(3)]

#
#t = traceur.StackTrace(x)    
#t.call()
#print(t.do_report())

#t = traceur.StackTrace(list_comprehension)
#t = traceur.DummyTrace(list_comprehension)
#t = traceur.DummyTrace(test)
#t = traceur.StackTrace(f1)
t = traceur.DummyTrace(f1)
#dis.dis(x)
t.call(10)
t.do_report()

