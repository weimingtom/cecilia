namespace cecilia 
{
	public partical class cecilia 
	{


		/* Parser generator interface */

		//extern grammar *meta_grammar(void);

		//struct _node;
		//extern grammar *pgen(struct _node *);
	}
}
