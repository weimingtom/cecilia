//20180118
#include "python.h"

const char *Py_GetPlatform()
{
	return PLATFORM;
}
