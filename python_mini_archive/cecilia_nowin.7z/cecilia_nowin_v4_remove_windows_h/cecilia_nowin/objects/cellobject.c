//20170410
#include "python.h"

PyObject *PyCell_New(PyObject *obj)
{
	PyCellObject *op;

	op = (PyCellObject *)PyObject_GC_New(PyCellObject, &PyCell_Type);
	op->ob_ref = obj;
	Py_XINCREF(obj);

	_PyObject_GC_TRACK(op);
	return (PyObject *)op;
}

PyObject *PyCell_Get(PyObject *op)
{
	if (!PyCell_Check(op)) 
	{
		PyErr_BadInternalCall();
		return NULL;
	}
	Py_XINCREF(((PyCellObject*)op)->ob_ref);
	return PyCell_GET(op);
}

int PyCell_Set(PyObject *op, PyObject *obj)
{
	if (!PyCell_Check(op)) 
	{
		PyErr_BadInternalCall();
		return -1;
	}
	Py_XDECREF(((PyCellObject*)op)->ob_ref);
	Py_XINCREF(obj);
	PyCell_SET(op, obj);
	return 0;
}

static void cell_dealloc(PyCellObject *op)
{
	_PyObject_GC_UNTRACK(op);
	Py_XDECREF(op->ob_ref);
	PyObject_GC_Del(op);
}

static int cell_compare(PyCellObject *a, PyCellObject *b)
{
	if (a->ob_ref == NULL) 
	{
		if (b->ob_ref == NULL)
		{
			return 0;
		}
		return -1;
	} 
	else if (b->ob_ref == NULL)
	{
		return 1;
	}
	return PyObject_Compare(a->ob_ref, b->ob_ref);
}

static PyObject *cell_repr(PyCellObject *op)
{
	if (op->ob_ref == NULL)
	{
		return PyString_FromFormat("<cell at %p: empty>", op);
	}

	return PyString_FromFormat("<cell at %p: %.80s object at %p>",
				   op, op->ob_ref->ob_type->tp_name,
				   op->ob_ref);
}

static int cell_traverse(PyCellObject *op, visitproc visit, void *arg)
{
	if (op->ob_ref)
	{
		return visit(op->ob_ref, arg);
	}
	return 0;
}

static int cell_clear(PyCellObject *op)
{
	Py_XDECREF(op->ob_ref);
	op->ob_ref = NULL;
	return 0;
}

PyTypeObject PyCell_Type = {
	PyObject_HEAD_INIT(&PyType_Type)
	0,
	"cell",
	sizeof(PyCellObject),
	0,
	(destructor)cell_dealloc,              
	0,                                      
	0,	                                
	0,					
	(cmpfunc)cell_compare,			
	(reprfunc)cell_repr,			
	0,					
	0,			         
	0,					
	0,					
	0,					
	0,					
	PyObject_GenericGetAttr,
	0,					
	0,					
	Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HAVE_GC,
 	0,					
 	(traverseproc)cell_traverse,
 	(inquiry)cell_clear,
};
