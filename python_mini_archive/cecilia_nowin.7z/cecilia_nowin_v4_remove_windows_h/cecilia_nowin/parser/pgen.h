//20170403
#pragma once

extern grammar *meta_grammar();
struct _node;
extern grammar *pgen(struct _node *);
